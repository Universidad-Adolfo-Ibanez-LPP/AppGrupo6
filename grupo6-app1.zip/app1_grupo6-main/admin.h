void llenar();
void sede_add(char * sede);
void piso_add(char * piso);
void seccion_add(char * seccion);