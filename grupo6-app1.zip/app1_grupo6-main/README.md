# app1_grupo6

Integrantes: 
Nicolas Soto
Carolina Santiba�ez 
Cristobal Sepulveda 
Daniel Bravo
Pablo Thieme


para compilar el programa:
gcc -o test main.c libros.c libros.h admin.c admin.h archivo.c archivo.h pablo.c pablo.h quitar.c quitar.h