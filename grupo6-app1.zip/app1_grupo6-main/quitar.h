int buscar_sede(char *nombre);
int borrar_sedelista(char *nombre);
void borrar_sede(char *nombre);
int buscar_piso(char *nombre);
void borrar_piso(char *nombre);
int borrar_pisolista(char *nombre);
int buscar_seccion(char *nombre);
void borrar_seccion(char *nombre);
int borrar_seccionlista(char *nombre);

