void EditSec();

void EditSede();

void EditPiso();
