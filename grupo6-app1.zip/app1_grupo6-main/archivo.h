int leer(int argc, char *argv[]);

void guardar(int argc, char *argv[]);